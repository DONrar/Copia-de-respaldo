package com.deudoresBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeudoresBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeudoresBackApplication.class, args);
	}

}
