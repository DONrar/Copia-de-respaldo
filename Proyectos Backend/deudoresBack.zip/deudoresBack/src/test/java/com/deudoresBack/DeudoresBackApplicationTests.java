package com.deudoresBack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeudoresBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
