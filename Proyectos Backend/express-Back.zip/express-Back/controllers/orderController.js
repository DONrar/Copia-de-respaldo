const pool = require('../config/db');

// Procesar pedido
exports.processOrder = async (req, res) => {
  const { userId } = req.params;
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // 1. Obtener productos del carrito
    const cartResult = await client.query(`
      SELECT c.product_id, c.quantity, p.price
      FROM cart c
      JOIN products p ON c.product_id = p.id
      WHERE c.user_id = $1
    `, [userId]);

    const cartItems = cartResult.rows;

    if (cartItems.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Carrito vacío' });
    }

    // 2. Calcular total
    const total = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

    // 3. Crear pedido
    const orderResult = await client.query(
      `INSERT INTO orders (user_id, total) VALUES ($1, $2) RETURNING id`,
      [userId, total]
    );
    const orderId = orderResult.rows[0].id;

    // 4. Insertar ítems del pedido y descontar stock
    for (const item of cartItems) {
      await client.query(`
        INSERT INTO order_items (order_id, product_id, quantity, price)
        VALUES ($1, $2, $3, $4)
      `, [orderId, item.product_id, item.quantity, item.price]);

      await client.query(`
        UPDATE products
        SET stock = stock - $1
        WHERE id = $2 AND stock >= $1
      `, [item.quantity, item.product_id]);
    }

    // 5. Vaciar carrito
    await client.query(`DELETE FROM cart WHERE user_id = $1`, [userId]);

    await client.query('COMMIT');

    res.status(201).json({ message: 'Pedido procesado exitosamente', orderId, total });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Error al procesar el pedido' });
  } finally {
    client.release();
  }
};


// Historial de compras del usuario
exports.getOrderHistory = async (req, res) => {
  const { userId } = req.params;

  try {
    // 1. Obtener todas las órdenes del usuario
    const ordersResult = await pool.query(
      `SELECT id, total, created_at FROM orders WHERE user_id = $1 ORDER BY created_at DESC`,
      [userId]
    );

    const orders = ordersResult.rows;

    // 2. Por cada orden, obtener sus ítems
    for (const order of orders) {
      const itemsResult = await pool.query(
        `SELECT p.name, oi.price, oi.quantity
         FROM order_items oi
         JOIN products p ON oi.product_id = p.id
         WHERE oi.order_id = $1`,
        [order.id]
      );

      order.items = itemsResult.rows;
    }

    res.json(orders);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener historial de compras' });
  }
};
