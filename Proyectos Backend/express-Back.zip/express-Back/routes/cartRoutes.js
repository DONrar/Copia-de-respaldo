const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cartController');

// Obtener carrito del usuario
router.get('/:userId', cartController.getCart);

// Agregar producto al carrito
router.post('/:userId/add', cartController.addToCart);

// Eliminar producto del carrito
router.delete('/:userId/remove/:productId', cartController.removeFromCart);

module.exports = router;
