const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

// Procesar pedido (convertir carrito en orden)
router.post('/process/:userId', orderController.processOrder);

// Historial de compras del usuario
router.get('/history/:userId', orderController.getOrderHistory);

module.exports = router;
