const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

// Obtener todos los productos
router.get('/', productController.getAll);

// Crear un producto
router.post('/', productController.create);

// Obtener un producto por ID
router.get('/:id', productController.getById);

// Actualizar un producto
router.put('/:id', productController.update);

// Eliminar un producto
router.delete('/:id', productController.delete);

module.exports = router;
