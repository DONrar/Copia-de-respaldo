package com.fiados_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiadosApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiadosApiApplication.class, args);
	}

}
